# Security Policy

Report security issues privately to the repository maintainer after publication.

This prototype intentionally avoids network calls, shell execution, and host mutation. If you add integrations, preserve the static boundary audit and document new trust boundaries.
