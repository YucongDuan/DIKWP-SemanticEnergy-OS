# DIKWP SemanticEnergy Recommendations

System: DIKWP SemanticEnergy OS 0.1.0
Weighted semantic-energy score: 0.3153
Waste index: 0.6847

## Portfolio Recommendations
- Create a semantic budget: high-energy inference must cite purpose, evidence, and expected value.
- Adopt evidence-first answer generation; unsupported claims are draining semantic value.
- Split context into stable memory, task context, and evidence chunks; avoid repeated mega-prompts.
- Add a pre-inference redaction gate for secrets and personal data.
- Replace proxy estimates with telemetry: GPU power draw, region carbon intensity, and batch utilization.

## Event-Level Recommendations
### evt_001 — allow — B / good, optimize selectively
- Keep current workflow; monitor with hardware telemetry for stronger energy proof.
### evt_002 — review — F / high waste or low semantic value
- Add source-backed claim cards; avoid unsupported 'best/only/guarantee' statements.
- Rewrite the prompt with an explicit P-layer: goal, value, constraints, time horizon, and feedback.
### evt_003 — block — F / high waste or low semantic value
- Add source-backed claim cards; avoid unsupported 'best/only/guarantee' statements.
- Rewrite the prompt with an explicit P-layer: goal, value, constraints, time horizon, and feedback.
- Use retrieval or summarization before inference; the event appears to carry large-context waste.
- Route low-risk tasks to a smaller model or batch them; reserve high-energy models for high-stakes tasks.
- Remove credential-like or sensitive fields before sending context to an AI model.
- Add a tool budget and require justification for each tool call after the threshold.