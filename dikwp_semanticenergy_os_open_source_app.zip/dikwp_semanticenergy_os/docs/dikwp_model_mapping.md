# DIKWP Model Mapping

## D / Data

Raw prompt, output, model name, tokens, latency, cost, sources, constraints, telemetry.

## I / Information

Differences and relations among purpose, output, evidence, token burden, energy burden, and risk.

## K / Knowledge

Heuristics and workflow knowledge that connect AI workload features to governance signals.

## W / Wisdom

Tradeoffs: do not reduce energy or cost by removing evidence, safety, privacy, human review, or legal boundary.

## P / Purpose

Local purpose of the AI workload, including goal, value, constraints, time horizon, and feedback expectations.

## R / Reliability

Proof tier for energy, carbon, evidence, and semantic value. Estimates are Provisional/Borrowed until hardware telemetry and external validation are available.
