# Governance Boundary

DIKWP SemanticEnergy OS must not be used to justify unsafe or deceptive optimization.

## Do not

- remove safety checks merely to reduce cost
- remove evidence requirements to improve speed
- down-rank human review for high-stakes outputs without governance approval
- send secrets or sensitive personal data to AI systems
- present proxy energy estimates as exact telemetry
- claim ESG compliance based only on this tool

## Do

- separate estimates from telemetry
- keep evidence and purpose ledgers
- mark borrowed reliability
- route sensitive data through redaction gates
- keep human review for high-stakes domains
- track both semantic value and resource burden
