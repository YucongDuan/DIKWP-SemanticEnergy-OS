# Architecture

## Input

A JSON file containing AI workload events:

- task
- purpose
- prompt
- output
- model
- tokens
- latency
- cost
- optional estimated energy
- optional carbon intensity
- sources
- constraints
- outcome rating
- metadata such as retries and tool calls

## Core pipeline

```text
AI workload log
  -> DIKWP event registration
  -> purpose coupling scoring
  -> evidence support scoring
  -> redundancy and unsupported-claim risk
  -> energy and carbon estimation
  -> semantic-energy score
  -> decision and recommendations
  -> portfolio report
```

## DIKWP mapping

- D: event payload, tokens, model, sources, raw prompt/output.
- I: relation between purpose, constraints, cost, latency, and output.
- K: scoring model and workflow knowledge.
- W: safety, evidence, privacy, carbon, and cost tradeoffs.
- P: the local purpose of the AI workload.
- R: reliability of estimates and proof level.

## Reliability model

- Hardware telemetry supplied: stronger RunProof.
- No telemetry supplied: energy/carbon are Borrowed/Provisional estimates.
- Evidence sources supplied: stronger evidence support.
- No evidence sources: unsupported claim risk can rise.

## Non-goals

- Not a guarantee of exact power draw.
- Not an ESG certification engine.
- Not a replacement for privacy review or security review.
- Not a tool for disabling safety controls to reduce cost.
