# GitHub Release Draft

## DIKWP SemanticEnergy OS v0.1.0

This first release introduces an open-source semantic FinOps layer for AI workloads.

### Included

- CLI analyzer for AI workload event logs
- DIKWP semantic registration
- purpose coupling score
- evidence support score
- redundancy and unsupported claim risk
- estimated energy and carbon ledger
- portfolio recommendations
- semantic budget policy output
- static boundary audit

### Demo

```bash
dikwp-semanticenergy analyze examples/sample_ai_workflow_log.json --policy configs/default_policy.json --out outputs/demo
```

### Boundary

Energy and carbon are estimates unless hardware telemetry is supplied. This project does not claim compliance certification.
