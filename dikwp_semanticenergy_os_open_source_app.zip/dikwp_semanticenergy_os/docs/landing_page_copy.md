# Landing Page Copy

## Hero

Stop paying for meaningless AI output.

DIKWP SemanticEnergy OS shows whether every AI call produced evidence-backed purpose value for its token, cost, and energy burden.

## Subheading

AI FinOps sees the bill. Observability sees latency. DIKWP SemanticEnergy sees the missing question: was the output semantically worth it?

## Features

- Purpose coupling score
- Evidence support score
- Redundancy and waste detection
- Estimated energy and carbon ledger
- Semantic budget policy
- DIKWP event registration
- CLI and dashboard-ready open-source core

## CTA

Download the open-source package and run your first semantic-energy audit in five minutes.
