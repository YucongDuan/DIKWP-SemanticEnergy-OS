# Roadmap

## 0.1

- JSON event log analyzer
- DIKWP registration
- semantic-energy score
- demo output
- static boundary audit

## 0.2

- OpenAI / Anthropic / Bedrock log adapters
- LangChain / LangSmith / CrewAI / AutoGen export adapters
- model routing recommendation engine

## 0.3

- hardware telemetry connector
- region-level carbon intensity connector
- cost allocation tags
- dashboard charts

## 0.4

- RAG evidence support quality model
- claim-to-source matching
- portfolio anomaly detection

## 1.0

- enterprise dashboard
- policy-as-code
- governance evidence pack
- semantic budget marketplace
