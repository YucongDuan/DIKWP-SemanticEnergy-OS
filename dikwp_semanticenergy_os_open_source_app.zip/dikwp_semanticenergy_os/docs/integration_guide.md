# Integration Guide

## Minimal CLI integration

Export your AI workload logs as JSON and run:

```bash
dikwp-semanticenergy analyze ai_events.json --policy configs/default_policy.json --out semanticenergy_out
```

## Event schema

```json
{
  "event_id": "evt_001",
  "task": "Answer support question",
  "purpose": "Accurately answer with policy citations",
  "prompt": "...",
  "output": "...",
  "model": "medium",
  "prompt_tokens": 800,
  "completion_tokens": 300,
  "latency_ms": 1200,
  "cost_usd": 0.004,
  "estimated_energy_j": null,
  "carbon_intensity_gco2_per_kwh": 420,
  "sources": ["policy_v3"],
  "constraints": ["cite source"],
  "outcome_rating": 0.9,
  "metadata": {"tool_calls": 1, "retries": 0}
}
```

## Telemetry upgrade path

For stronger proof, attach:

- GPU or accelerator power draw
- duration
- batch size
- hardware utilization
- data center region
- carbon intensity
- model route
- cache hit / miss

## Model-router use case

Use event scores to decide which model tier is justified:

- low-risk, low-evidence, low-purpose tasks -> small model
- high-evidence, high-stakes tasks -> larger model with citations
- unsupported/high-redundancy tasks -> rewrite prompt before rerun
