from __future__ import annotations

import math
from typing import Dict, Any, List

from .models import AIWorkloadEvent
from .text_utils import tokenize, jaccard, redundancy_score, count_claim_like_sentences, clamp, privacy_risk

DEFAULT_JOULES_PER_1K_TOKENS = 18.0  # conservative proxy for demo; replace with telemetry when available.
KWH_PER_JOULE = 1 / 3_600_000.0


def estimate_energy_j(event: AIWorkloadEvent, policy: Dict[str, Any]) -> float:
    if event.estimated_energy_j is not None:
        return max(0.0, float(event.estimated_energy_j))
    joules_per_1k = float(policy.get("joules_per_1k_tokens", DEFAULT_JOULES_PER_1K_TOKENS))
    model_multiplier = float(policy.get("model_multipliers", {}).get(event.model, 1.0))
    tool_call_multiplier = 1.0 + 0.08 * int(event.metadata.get("tool_calls", 0))
    return max(0.001, (event.total_tokens / 1000.0) * joules_per_1k * model_multiplier * tool_call_multiplier)


def estimate_carbon_gco2(event: AIWorkloadEvent, energy_j: float, policy: Dict[str, Any]) -> float:
    ci = event.carbon_intensity_gco2_per_kwh
    if ci is None:
        ci = policy.get("default_carbon_intensity_gco2_per_kwh", 420.0)
    return max(0.0, energy_j * KWH_PER_JOULE * float(ci))


def purpose_coupling(event: AIWorkloadEvent) -> float:
    purpose_toks = tokenize(event.purpose + " " + " ".join(event.constraints))
    output_toks = tokenize(event.output + " " + event.task)
    overlap = jaccard(purpose_toks, output_toks)
    outcome = event.outcome_rating if event.outcome_rating is not None else 0.65
    return clamp(0.45 + 0.40 * overlap + 0.15 * float(outcome))


def evidence_support(event: AIWorkloadEvent) -> float:
    claim_count = count_claim_like_sentences(event.output)
    if claim_count == 0:
        return 0.5 if not event.sources else 0.75
    source_score = clamp(len(event.sources) / max(1, claim_count))
    explicit_source_words = sum(1 for s in event.sources if s and s.lower() in (event.output or "").lower())
    link_score = clamp(explicit_source_words / max(1, len(event.sources))) if event.sources else 0.0
    outcome = event.outcome_rating if event.outcome_rating is not None else 0.55
    return clamp(0.55 * source_score + 0.20 * link_score + 0.25 * float(outcome))


def unsupported_claim_risk(event: AIWorkloadEvent) -> float:
    claims = count_claim_like_sentences(event.output)
    if claims == 0:
        return 0.0
    return clamp((claims - len(event.sources)) / max(1, claims))


def semantic_value(event: AIWorkloadEvent, evidence_score: float, purpose_score: float, red_score: float) -> float:
    output_len_factor = clamp(math.log1p(len(event.output or "")) / 8.0)
    return clamp(0.35 * evidence_score + 0.35 * purpose_score + 0.20 * red_score + 0.10 * output_len_factor)


def semantic_energy_score(semantic_value_score: float, energy_j: float, policy: Dict[str, Any]) -> float:
    target_energy = float(policy.get("target_energy_j_per_event", 40.0))
    energy_efficiency = clamp(target_energy / max(target_energy, energy_j))
    return clamp(0.70 * semantic_value_score + 0.30 * energy_efficiency)


def grade(score: float) -> str:
    if score >= 0.88:
        return "A / strong semantic-energy efficiency"
    if score >= 0.74:
        return "B / good, optimize selectively"
    if score >= 0.60:
        return "C / usable but waste exists"
    if score >= 0.45:
        return "D / inefficient or under-evidenced"
    return "F / high waste or low semantic value"


def risk_categories(event: AIWorkloadEvent, unsupported: float, privacy: float, energy_j: float, policy: Dict[str, Any]) -> List[str]:
    risks: List[str] = []
    if unsupported > 0.45:
        risks.append("unsupported_claims")
    if privacy > 0.0:
        risks.append("sensitive_data_exposure")
    if event.total_tokens > int(policy.get("large_context_token_threshold", 12000)):
        risks.append("large_context_waste")
    if energy_j > float(policy.get("high_energy_event_j", 250.0)):
        risks.append("high_energy_event")
    if event.cost_usd > float(policy.get("high_cost_event_usd", 0.50)):
        risks.append("high_cost_event")
    if int(event.metadata.get("retries", 0)) > 1:
        risks.append("retry_waste")
    if int(event.metadata.get("tool_calls", 0)) > int(policy.get("tool_call_review_threshold", 5)):
        risks.append("tool_call_sprawl")
    return risks
