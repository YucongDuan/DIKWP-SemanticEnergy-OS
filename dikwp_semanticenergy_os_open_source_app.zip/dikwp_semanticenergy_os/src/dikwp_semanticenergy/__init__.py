"""DIKWP SemanticEnergy OS: AI semantic value, cost, and energy governance."""
__version__ = "0.1.0"
