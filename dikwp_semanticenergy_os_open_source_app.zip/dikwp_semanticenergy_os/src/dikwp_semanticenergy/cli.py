from __future__ import annotations

import argparse
import json
from pathlib import Path

from .analyzer import load_events, load_policy, assess_portfolio
from .reports import write_report
from .static_audit import audit_source


def main() -> None:
    parser = argparse.ArgumentParser(description="DIKWP SemanticEnergy OS")
    sub = parser.add_subparsers(dest="cmd", required=True)

    analyze = sub.add_parser("analyze", help="Analyze AI workload event logs")
    analyze.add_argument("input", help="JSON file with events")
    analyze.add_argument("--policy", default=None, help="Optional policy JSON")
    analyze.add_argument("--out", default="outputs", help="Output directory")

    audit = sub.add_parser("static-audit", help="Run static boundary audit")
    audit.add_argument("root", help="Source root to audit")
    audit.add_argument("--out", default=None, help="Optional report path")

    args = parser.parse_args()

    if args.cmd == "analyze":
        events = load_events(args.input)
        policy = load_policy(args.policy) if args.policy else {}
        report = assess_portfolio(events, policy)
        write_report(report, args.out)
        print(json.dumps(report.to_dict(), ensure_ascii=False, indent=2))
    elif args.cmd == "static-audit":
        report = audit_source(args.root)
        if args.out:
            Path(args.out).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
