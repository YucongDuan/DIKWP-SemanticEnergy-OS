from __future__ import annotations

import json

try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None

from .analyzer import event_from_dict, assess_portfolio


def main() -> None:  # pragma: no cover
    if st is None:
        raise RuntimeError("Streamlit is not installed. Install with: pip install streamlit")
    st.set_page_config(page_title="DIKWP SemanticEnergy OS", layout="wide")
    st.title("DIKWP SemanticEnergy OS")
    st.caption("AI semantic value, cost, energy, and purpose-governance dashboard")
    uploaded = st.file_uploader("Upload AI workload events JSON", type=["json"])
    if uploaded:
        data = json.loads(uploaded.read().decode("utf-8"))
        if isinstance(data, dict) and "events" in data:
            data = data["events"]
        events = [event_from_dict(x) for x in data]
        report = assess_portfolio(events).to_dict()
        st.metric("Weighted semantic-energy score", report["weighted_semantic_energy_score"])
        st.metric("Waste index", report["waste_index"])
        st.metric("Total estimated energy (J)", report["total_estimated_energy_j"])
        st.json(report)
    else:
        st.info("Upload examples/sample_ai_workflow_log.json to try the dashboard.")


if __name__ == "__main__":
    main()
