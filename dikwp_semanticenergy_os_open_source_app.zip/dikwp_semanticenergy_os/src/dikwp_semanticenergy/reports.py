from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Dict, Any

from .models import PortfolioReport


def write_report(report: PortfolioReport, out_dir: str | Path) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    data = report.to_dict()
    (out / "semantic_energy_report.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    write_event_csv(data, out / "event_scores.csv")
    write_recommendations_md(data, out / "recommendations.md")
    write_semantic_budget_policy(data, out / "semantic_budget_policy.json")


def write_event_csv(data: Dict[str, Any], path: Path) -> None:
    rows = data.get("events", [])
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "event_id", "decision", "semantic_energy_score", "purpose_coupling_score",
            "evidence_support_score", "redundancy_score", "unsupported_claim_risk",
            "privacy_risk", "estimated_energy_j", "estimated_carbon_gco2", "cost_usd",
            "total_tokens", "grade", "risk_categories"
        ])
        writer.writeheader()
        for r in rows:
            row = {k: r.get(k) for k in writer.fieldnames}
            row["risk_categories"] = ";".join(r.get("risk_categories", []))
            writer.writerow(row)


def write_recommendations_md(data: Dict[str, Any], path: Path) -> None:
    lines = [
        "# DIKWP SemanticEnergy Recommendations",
        "",
        f"System: {data.get('system')} {data.get('version')}",
        f"Weighted semantic-energy score: {data.get('weighted_semantic_energy_score')}",
        f"Waste index: {data.get('waste_index')}",
        "",
        "## Portfolio Recommendations",
    ]
    for r in data.get("recommendations", []):
        lines.append(f"- {r}")
    lines += ["", "## Event-Level Recommendations"]
    for e in data.get("events", []):
        lines.append(f"### {e.get('event_id')} — {e.get('decision')} — {e.get('grade')}")
        for rec in e.get("recommendations", []):
            lines.append(f"- {rec}")
    path.write_text("\n".join(lines), encoding="utf-8")


def write_semantic_budget_policy(data: Dict[str, Any], path: Path) -> None:
    policy = {
        "name": "DIKWP Semantic Budget Policy",
        "purpose": "Reduce AI cost and energy waste without removing evidence, privacy, safety, or purpose controls.",
        "thresholds": {
            "minimum_semantic_energy_score": 0.70,
            "review_if_unsupported_claim_risk_above": 0.35,
            "review_if_large_context_tokens_above": 12000,
            "block_sensitive_data_exposure": True,
        },
        "required_tags": ["team", "purpose", "model", "run_type", "evidence_tier", "approval_tier"],
        "portfolio_summary": {
            "weighted_semantic_energy_score": data.get("weighted_semantic_energy_score"),
            "waste_index": data.get("waste_index"),
            "total_estimated_energy_j": data.get("total_estimated_energy_j"),
            "total_cost_usd": data.get("total_cost_usd"),
        },
    }
    path.write_text(json.dumps(policy, ensure_ascii=False, indent=2), encoding="utf-8")
