from __future__ import annotations

import re
from collections import Counter
from typing import Iterable, List, Set

WORD_RE = re.compile(r"[A-Za-z0-9_\-]+|[\u4e00-\u9fff]")
CLAIM_MARKERS = re.compile(r"\b(is|are|was|were|will|can|should|must|prove|guarantee|best|first|only|always|never)\b|是|证明|保证|必须|应该|唯一|总是|从不|最好")
SENSITIVE_RE = re.compile(r"\b(api[_ -]?key|password|secret|token|credential|private key|ssn|id card|身份证|密码|密钥|令牌|凭证)\b", re.I)


def tokenize(text: str) -> List[str]:
    return [m.group(0).lower() for m in WORD_RE.finditer(text or "")]


def jaccard(a: Iterable[str], b: Iterable[str]) -> float:
    sa: Set[str] = set(a)
    sb: Set[str] = set(b)
    if not sa and not sb:
        return 0.0
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / max(1, len(sa | sb))


def clamp(x: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, x))


def redundancy_score(text: str) -> float:
    """Higher is better: 1 means low redundancy, 0 means extremely repetitive."""
    toks = tokenize(text)
    if not toks:
        return 0.0
    counts = Counter(toks)
    unique_ratio = len(counts) / len(toks)
    repeated_top = counts.most_common(1)[0][1] / len(toks)
    return clamp(0.65 * unique_ratio + 0.35 * (1 - repeated_top))


def count_claim_like_sentences(text: str) -> int:
    parts = re.split(r"[。！？!?\n]+", text or "")
    return sum(1 for p in parts if CLAIM_MARKERS.search(p))


def privacy_risk(text: str) -> float:
    if not text:
        return 0.0
    hits = len(SENSITIVE_RE.findall(text))
    return clamp(hits / 3)
