from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Optional


@dataclass
class AIWorkloadEvent:
    event_id: str
    task: str
    purpose: str
    prompt: str
    output: str
    model: str = "unknown"
    prompt_tokens: int = 0
    completion_tokens: int = 0
    latency_ms: int = 0
    cost_usd: float = 0.0
    estimated_energy_j: Optional[float] = None
    carbon_intensity_gco2_per_kwh: Optional[float] = None
    sources: List[str] = field(default_factory=list)
    constraints: List[str] = field(default_factory=list)
    outcome_rating: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def total_tokens(self) -> int:
        return max(0, int(self.prompt_tokens)) + max(0, int(self.completion_tokens))

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class EventAssessment:
    event_id: str
    decision: str
    semantic_energy_score: float
    purpose_coupling_score: float
    evidence_support_score: float
    redundancy_score: float
    unsupported_claim_risk: float
    privacy_risk: float
    estimated_energy_j: float
    estimated_carbon_gco2: float
    cost_usd: float
    total_tokens: int
    grade: str
    risk_categories: List[str]
    recommendations: List[str]
    dikwp_record: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class PortfolioReport:
    system: str
    version: str
    event_count: int
    weighted_semantic_energy_score: float
    mean_purpose_coupling: float
    mean_evidence_support: float
    total_estimated_energy_j: float
    total_estimated_carbon_gco2: float
    total_cost_usd: float
    waste_index: float
    decisions: Dict[str, int]
    top_risks: Dict[str, int]
    recommendations: List[str]
    events: List[Dict[str, Any]]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
