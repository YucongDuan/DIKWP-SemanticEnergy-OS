from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable, List

from .models import AIWorkloadEvent, EventAssessment, PortfolioReport
from .metrics import (
    estimate_energy_j,
    estimate_carbon_gco2,
    purpose_coupling,
    evidence_support,
    unsupported_claim_risk,
    semantic_value,
    semantic_energy_score,
    grade,
    risk_categories,
)
from .text_utils import redundancy_score, privacy_risk, clamp
from .dikwp import register_event

SYSTEM_NAME = "DIKWP SemanticEnergy OS"
VERSION = "0.1.0"


def load_policy(path: str | Path | None = None) -> Dict[str, Any]:
    if path is None:
        return {}
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Policy file not found: {p}")
    return json.loads(p.read_text(encoding="utf-8"))


def event_from_dict(d: Dict[str, Any]) -> AIWorkloadEvent:
    allowed = {f.name for f in AIWorkloadEvent.__dataclass_fields__.values()}  # type: ignore[attr-defined]
    clean = {k: v for k, v in d.items() if k in allowed}
    return AIWorkloadEvent(**clean)


def load_events(path: str | Path) -> List[AIWorkloadEvent]:
    p = Path(path)
    data = json.loads(p.read_text(encoding="utf-8"))
    if isinstance(data, dict) and "events" in data:
        data = data["events"]
    if not isinstance(data, list):
        raise ValueError("Input must be a list of events or an object with an 'events' list.")
    return [event_from_dict(x) for x in data]


def assess_event(event: AIWorkloadEvent, policy: Dict[str, Any] | None = None) -> EventAssessment:
    policy = policy or {}
    energy_j = estimate_energy_j(event, policy)
    carbon_g = estimate_carbon_gco2(event, energy_j, policy)
    purpose_score = purpose_coupling(event)
    evidence_score = evidence_support(event)
    red = redundancy_score(event.prompt + "\n" + event.output)
    unsupported = unsupported_claim_risk(event)
    pr = privacy_risk(event.prompt + "\n" + event.output)
    semantic_val = semantic_value(event, evidence_score, purpose_score, red)
    ses = semantic_energy_score(semantic_val, energy_j, policy)
    risks = risk_categories(event, unsupported, pr, energy_j, policy)
    decision = decide(ses, risks, policy)
    recommendations = make_recommendations(event, ses, purpose_score, evidence_score, red, unsupported, pr, energy_j, risks)
    reliability = "Supported / RunProof" if event.estimated_energy_j is not None else "Provisional / Borrowed estimate"
    dikwp_record = register_event(event, reliability=reliability, notes="Use hardware telemetry for stronger energy proof.")
    return EventAssessment(
        event_id=event.event_id,
        decision=decision,
        semantic_energy_score=round(ses, 4),
        purpose_coupling_score=round(purpose_score, 4),
        evidence_support_score=round(evidence_score, 4),
        redundancy_score=round(red, 4),
        unsupported_claim_risk=round(unsupported, 4),
        privacy_risk=round(pr, 4),
        estimated_energy_j=round(energy_j, 6),
        estimated_carbon_gco2=round(carbon_g, 6),
        cost_usd=round(float(event.cost_usd), 6),
        total_tokens=event.total_tokens,
        grade=grade(ses),
        risk_categories=risks,
        recommendations=recommendations,
        dikwp_record=dikwp_record,
    )


def decide(score: float, risks: List[str], policy: Dict[str, Any]) -> str:
    block_risks = set(policy.get("block_risks", ["sensitive_data_exposure"]))
    if block_risks.intersection(risks):
        return "block"
    if score < float(policy.get("review_score_threshold", 0.60)):
        return "review"
    if risks:
        return "review"
    return "allow"


def make_recommendations(event: AIWorkloadEvent, ses: float, purpose: float, evidence: float, red: float, unsupported: float, privacy: float, energy_j: float, risks: List[str]) -> List[str]:
    recs: List[str] = []
    if evidence < 0.55 or unsupported > 0.35:
        recs.append("Add source-backed claim cards; avoid unsupported 'best/only/guarantee' statements.")
    if purpose < 0.60:
        recs.append("Rewrite the prompt with an explicit P-layer: goal, value, constraints, time horizon, and feedback.")
    if red < 0.45:
        recs.append("Compress repeated instructions and separate stable policy from per-task context.")
    if event.total_tokens > 12000:
        recs.append("Use retrieval or summarization before inference; the event appears to carry large-context waste.")
    if energy_j > 250:
        recs.append("Route low-risk tasks to a smaller model or batch them; reserve high-energy models for high-stakes tasks.")
    if privacy > 0:
        recs.append("Remove credential-like or sensitive fields before sending context to an AI model.")
    if "tool_call_sprawl" in risks:
        recs.append("Add a tool budget and require justification for each tool call after the threshold.")
    if not recs:
        recs.append("Keep current workflow; monitor with hardware telemetry for stronger energy proof.")
    return recs


def assess_portfolio(events: Iterable[AIWorkloadEvent], policy: Dict[str, Any] | None = None) -> PortfolioReport:
    policy = policy or {}
    assessments = [assess_event(e, policy) for e in events]
    n = len(assessments)
    if n == 0:
        raise ValueError("No events to assess.")
    total_tokens = sum(a.total_tokens for a in assessments)
    weights = [max(1, a.total_tokens) / max(1, total_tokens) for a in assessments]
    weighted_score = sum(a.semantic_energy_score * w for a, w in zip(assessments, weights))
    mean_purpose = sum(a.purpose_coupling_score for a in assessments) / n
    mean_evidence = sum(a.evidence_support_score for a in assessments) / n
    total_energy = sum(a.estimated_energy_j for a in assessments)
    total_carbon = sum(a.estimated_carbon_gco2 for a in assessments)
    total_cost = sum(a.cost_usd for a in assessments)
    waste_index = clamp(1.0 - weighted_score)
    decisions: Dict[str, int] = {}
    risk_counts: Dict[str, int] = {}
    for a in assessments:
        decisions[a.decision] = decisions.get(a.decision, 0) + 1
        for r in a.risk_categories:
            risk_counts[r] = risk_counts.get(r, 0) + 1
    portfolio_recs = make_portfolio_recommendations(weighted_score, waste_index, risk_counts, total_energy, total_cost)
    return PortfolioReport(
        system=SYSTEM_NAME,
        version=VERSION,
        event_count=n,
        weighted_semantic_energy_score=round(weighted_score, 4),
        mean_purpose_coupling=round(mean_purpose, 4),
        mean_evidence_support=round(mean_evidence, 4),
        total_estimated_energy_j=round(total_energy, 6),
        total_estimated_carbon_gco2=round(total_carbon, 6),
        total_cost_usd=round(total_cost, 6),
        waste_index=round(waste_index, 4),
        decisions=decisions,
        top_risks=dict(sorted(risk_counts.items(), key=lambda kv: kv[1], reverse=True)),
        recommendations=portfolio_recs,
        events=[a.to_dict() for a in assessments],
    )


def make_portfolio_recommendations(weighted_score: float, waste_index: float, risks: Dict[str, int], total_energy: float, total_cost: float) -> List[str]:
    recs: List[str] = []
    if weighted_score < 0.70:
        recs.append("Create a semantic budget: high-energy inference must cite purpose, evidence, and expected value.")
    if risks.get("unsupported_claims", 0):
        recs.append("Adopt evidence-first answer generation; unsupported claims are draining semantic value.")
    if risks.get("large_context_waste", 0):
        recs.append("Split context into stable memory, task context, and evidence chunks; avoid repeated mega-prompts.")
    if risks.get("sensitive_data_exposure", 0):
        recs.append("Add a pre-inference redaction gate for secrets and personal data.")
    if total_cost > 10:
        recs.append("Integrate with FinOps tagging: team, purpose, model, run type, and approval tier.")
    if total_energy > 1000:
        recs.append("Replace proxy estimates with telemetry: GPU power draw, region carbon intensity, and batch utilization.")
    if not recs:
        recs.append("Portfolio is acceptable; continue monitoring cost, carbon, evidence support, and purpose coupling.")
    return recs
