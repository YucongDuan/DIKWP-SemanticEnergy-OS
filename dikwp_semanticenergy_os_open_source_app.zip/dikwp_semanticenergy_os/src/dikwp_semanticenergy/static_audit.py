from __future__ import annotations

import ast
from pathlib import Path
from typing import Dict, List, Any

FORBIDDEN_IMPORTS = {"subprocess", "socket", "requests", "httpx", "ftplib", "paramiko"}
FORBIDDEN_CALL_NAMES = {"system", "popen", "remove", "unlink", "rmtree"}


def audit_source(root: str | Path) -> Dict[str, Any]:
    root = Path(root)
    findings: List[Dict[str, str]] = []
    for path in root.rglob("*.py"):
        if "__pycache__" in str(path):
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except SyntaxError as exc:
            findings.append({"file": str(path), "kind": "syntax_error", "detail": str(exc)})
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    name = alias.name.split(".")[0]
                    if name in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(path), "kind": "forbidden_import", "detail": alias.name})
            elif isinstance(node, ast.ImportFrom):
                name = (node.module or "").split(".")[0]
                if name in FORBIDDEN_IMPORTS:
                    findings.append({"file": str(path), "kind": "forbidden_import", "detail": node.module or ""})
            elif isinstance(node, ast.Call):
                func = node.func
                call_name = ""
                if isinstance(func, ast.Attribute):
                    call_name = func.attr
                elif isinstance(func, ast.Name):
                    call_name = func.id
                if call_name in FORBIDDEN_CALL_NAMES:
                    findings.append({"file": str(path), "kind": "forbidden_call", "detail": call_name})
    return {
        "status": "PASS" if not findings else "REVIEW",
        "finding_count": len(findings),
        "findings": findings,
    }
