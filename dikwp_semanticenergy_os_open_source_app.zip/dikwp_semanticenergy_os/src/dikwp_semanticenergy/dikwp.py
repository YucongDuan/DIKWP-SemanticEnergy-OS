from __future__ import annotations

from typing import Dict, Any

from .models import AIWorkloadEvent


def register_event(event: AIWorkloadEvent, reliability: str, notes: str = "") -> Dict[str, Any]:
    """Create a compact DIKWP semantic record for an AI workload event."""
    return {
        "D": {
            "event_id": event.event_id,
            "task": event.task,
            "model": event.model,
            "prompt_tokens": event.prompt_tokens,
            "completion_tokens": event.completion_tokens,
            "sources": event.sources,
        },
        "I": {
            "purpose": event.purpose,
            "constraints": event.constraints,
            "latency_ms": event.latency_ms,
            "cost_usd": event.cost_usd,
        },
        "K": {
            "expected_use": "Estimate semantic value per token, dollar, and joule for AI workload governance.",
            "method": "Heuristic DIKWP scoring: purpose coupling, evidence support, redundancy, risk, and estimated energy.",
        },
        "W": {
            "risk_boundary": "Do not optimize cost by removing safety, privacy, evidence custody, or human review where needed.",
            "value_tradeoff": "Reduce waste while preserving truthfulness, auditability, and purpose continuity.",
        },
        "P": {
            "local_purpose": event.purpose,
            "success_condition": "High evidence-supported semantic value with low redundancy, low risk, and acceptable energy/cost.",
        },
        "R": {
            "reliability": reliability,
            "notes": notes,
            "borrowed_reliability": "Energy and carbon are estimates unless hardware telemetry is supplied.",
        },
    }
