# Code of Conduct

Be precise, civil, and evidence-oriented. Do not use this project to misrepresent energy, carbon, safety, or compliance claims.
