from dikwp_semanticenergy.analyzer import load_events, assess_portfolio
from dikwp_semanticenergy.static_audit import audit_source


def test_demo_assessment_runs():
    events = load_events('examples/sample_ai_workflow_log.json')
    report = assess_portfolio(events)
    assert report.event_count == 3
    assert 0 <= report.weighted_semantic_energy_score <= 1
    assert report.decisions.get('block', 0) >= 1


def test_sensitive_event_blocked():
    events = load_events('examples/sample_ai_workflow_log.json')
    report = assess_portfolio(events)
    event3 = [e for e in report.events if e['event_id'] == 'evt_003'][0]
    assert event3['decision'] == 'block'
    assert 'sensitive_data_exposure' in event3['risk_categories']


def test_static_audit_passes():
    report = audit_source('src')
    assert report['status'] == 'PASS'
