# Contributing

Contributions are welcome. Please keep the project evidence-first and governance-safe.

## Rules

- Do not add network exfiltration, shell execution, or host mutation features.
- Do not present proxy energy estimates as exact telemetry.
- Keep DIKWP attribution in NOTICE and CITATION.cff.
- Add tests for new scoring or policy logic.
